import React from 'react'
import { Button, Container, Nav, Navbar, NavDropdown } from 'react-bootstrap'
import { Link, useHistory } from 'react-router-dom'

const CustomNavbar = () => {

    const history = useHistory()

    const token = localStorage.getItem('token')

    const Logout = () => {
        localStorage.clear()
        history.push('/')
    }

    return (
        <div>
            <Navbar bg="dark" variant="dark" expand="lg">
                <Container>
                    <Navbar.Brand href="#home">Article Management</Navbar.Brand>
                    <Navbar.Toggle aria-controls="basic-navbar-nav" />
                    <Navbar.Collapse id="basic-navbar-nav">
                        <Nav className="mr-auto">
                            <Link to="/articles" className="nav-link">Articles</Link>
                            <Link to="/create-article" className="nav-link">Create New Article</Link>
                        </Nav>

                        <Button onClick={Logout}>Logout</Button>

                        {/* {token? <Button onClick={Logout}>Logout</Button> : <div></div>} */}
                        
                    </Navbar.Collapse>
                </Container>
            </Navbar>
        </div>
    )
}

export default CustomNavbar
