import React, { useState } from 'react'
import { Button, Card, Container, Form } from 'react-bootstrap'
import { useHistory } from 'react-router'
import {authLogin} from '../services/Service'

const Login = () => {

    const [email, SetEmail] = useState('')
    const [password, SetPassword] = useState('')
    const history = useHistory()

    const handleSubmit = async () => {
        const response = await authLogin({ email, password });
        if(response.token==null) {
            alert('Invalid Credentials')
        }
        else{
            localStorage.setItem("token", response.token)
            history.push('/articles')
        }
        
    }

    return (
        <div className="Login-page">
            <Container>
                <Card>
                    <Card.Header>
                        <h2>Login</h2>
                    </Card.Header>
                    <Card.Body>
                        <Form.Group controlId="formBasicEmail">
                            <Form.Label>Email</Form.Label>
                            <Form.Control 
                                type="email" 
                                placeholder="Email" 
                                value = {email}
                                onChange = {(e) => SetEmail(e.target.value)}
                            />
                        </Form.Group>
                        <Form.Group controlId="formBasicPassword">
                            <Form.Label>Password</Form.Label>
                            <Form.Control 
                                type="password" 
                                placeholder="Password" 
                                value = {password}
                                onChange = {(e) => SetPassword(e.target.value)}
                            />
                        </Form.Group>
                        <Button 
                            variant="primary" 
                            type="submit"
                            onClick = {handleSubmit}
                        >
                            Login
                        </Button>
                    </Card.Body>
                </Card>
            </Container>
        </div>
    )
}

export default Login
