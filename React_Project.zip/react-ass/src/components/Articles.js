import React, { useEffect, useState } from 'react'
import { Card, Container, Jumbotron, Row } from 'react-bootstrap'
import { Link, useHistory } from 'react-router-dom'
import {getArticles} from '../services/Service'

const Articles = () => {

    const [articles, setArticles] = useState([])
    const [loaded, setLoaded] = useState(false)
    const history = useHistory()

    useEffect(() => {
        setTimeout(async () => {
            const articles = await getArticles()

            setArticles(articles)

            setLoaded(true)
        }, 300);
    }, [])

    if(!loaded) {
        return (
            <div
                style={{ height: "100vh", alignItems: "center" }}
                className="d-flex justify-content-center"
            >
                <div
                    style={{ width: "3rem", height: "3rem" }}
                    className="spinner-border"
                    role="status"
                >
                    <span className="visually-hidden"></span>
                </div>
            </div>
        )
    }

    if(!localStorage.getItem('token')) {
        console.log("reaching here")
        history.push('/')
    }

    return (
        <div>
            <Jumbotron>
                <h1>Articles</h1>
            </Jumbotron>
            <Container>
                {articles.map((item, index) => {

                    const url = `/articles/${item.slug}`

                    return (
                        <Row className="justify-content-center" key={index}>
                            <div className="col-6">
                                <Link to={url}>
                                    <Card className="mb-3">
                                        <Card.Header>
                                            <h3>{item.title}</h3>
                                            {item.description}
                                        </Card.Header>
                                        {/* <Card.Body>
                                            {item.body}
                                        </Card.Body>
                                        <Card.Footer>
                                            postedby - {item.author.username}
                                        </Card.Footer> */}
                                    </Card>
                                </Link>
                            </div>
                        </Row>
                    )
                })}
            </Container>
        </div>
    )
}

export default Articles
