import React, { useState } from 'react'
import { Button, Card, Container, Form } from 'react-bootstrap'
import { useHistory } from 'react-router'
import {postArticle} from '../services/Service'

const CreateArticle = () => {

    const history = useHistory()

    const [title, setTitle] = useState('')
    const [description, setDescription] = useState('')
    const [body, setBody] = useState('')
    const [tags, setTags] = useState('')

    const handleSubmit = async () => {
        const tagList = tags.split(',').map(item => item.trim())

        if(!title || !description || !body) {
            alert("Enter all required fields")
        }
        else {
            const response = await postArticle({title, description, body, tagList})
            alert("Article saved successfully")
            setTitle("")
            setDescription("")
            setBody("")
            setTags("")

            const url = `/articles/${response.article.slug}`
            
            history.push(url)

        }
    }

    if(!localStorage.getItem('token')) {
        history.push('/')
    }

    return (
        <div className="create-article-page">
            <Container>
                <Card>
                    <Card.Header>
                        <h2>Create New Article</h2>
                    </Card.Header>
                    <Card.Body>
                        <Form.Group controlId="formBasicEmail">
                            <Form.Label>Title*</Form.Label>
                            <Form.Control 
                                type="text" 
                                placeholder="Title" 
                                value = {title}
                                onChange = {(e) => setTitle(e.target.value)}
                            />
                        </Form.Group>
                        <Form.Group controlId="formBasicEmail">
                            <Form.Label>Description*</Form.Label>
                            <Form.Control 
                                type="text" 
                                placeholder="Description" 
                                value = {description}
                                onChange = {(e) => setDescription(e.target.value)}
                            />
                        </Form.Group>
                        <Form.Group controlId="formBasicEmail">
                            <Form.Label>Tags (Comma Separated)</Form.Label>
                            <Form.Control 
                                type="text" 
                                placeholder="Description" 
                                value = {tags}
                                onChange = {(e) => setTags(e.target.value)}
                            />
                        </Form.Group>
                        <Form.Group controlId="exampleForm.ControlTextarea1">
                            <Form.Label>Body*</Form.Label>
                            <Form.Control 
                                as="textarea" 
                                rows={3} 
                                value = {body}
                                onChange = {(e) => setBody(e.target.value)}
                            />
                        </Form.Group>
                        <Button
                            variant="primary" 
                            type="submit"
                            onClick = {handleSubmit}
                        >
                            Submit
                        </Button>
                    </Card.Body>
                </Card>
            </Container>
        </div>
    )
}

export default CreateArticle
