import React, { useEffect, useState } from 'react'
import { Button, Card, Container, Jumbotron } from 'react-bootstrap'
import { useHistory, useParams } from 'react-router'
import { delArticle, getArticle, getUser } from '../services/Service'

const ArticlesDetails = () => {
    const {slug} = useParams()
    const [article, setArticle] = useState([])
    const [user, setUser] = useState(null)
    const [loaded, setLoaded] = useState(false)
    const history = useHistory()

    useEffect(() => {
        setTimeout(async () => {
            const article = await getArticle(slug)
            const user = await getUser()
            setArticle(article)
            setUser(user)
            setLoaded(true)
        }, 300);
    }, [slug])


    const deleteArticle  = async () => {
        const response = await delArticle(article.slug)
        history.push('/articles')
    }


    if(!loaded) {
        return (
            <div
                style={{ height: "100vh", alignItems: "center" }}
                className="d-flex justify-content-center"
            >
                <div
                    style={{ width: "3rem", height: "3rem" }}
                    className="spinner-border"
                    role="status"
                >
                    <span className="visually-hidden"></span>
                </div>
            </div>
        )
    }

    return (
        <div>
            <Jumbotron>
                <h2>{article.title}</h2>
                <p><em>--{article.author.username}</em></p>

                {article.author.username===user.username ? <Button className="btn-danger" onClick={deleteArticle}>Delete</Button>: <div></div>}
            </Jumbotron>
            <Container>
                <Card>
                    <Card.Header>
                        <h4>{article.description}</h4>
                    </Card.Header>
                    <Card.Body>
                        <p>{article.body}</p>
                    </Card.Body>
                </Card>
            </Container>
        </div>
    )
}

export default ArticlesDetails
