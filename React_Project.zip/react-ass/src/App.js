import React from 'react'
import { Route, Switch } from 'react-router'
import { BrowserRouter } from 'react-router-dom'
import Articles from './components/Articles'
import ArticlesDetails from './components/ArticlesDetails'
import CreateArticle from './components/CreateArticle'
import CustomNavbar from './components/CustomNavbar'
import Login from './components/Login'

const App = () => {
  return (
    <div>
      <BrowserRouter>
        <CustomNavbar/>
        <Switch>
          <Route exact path="/">
            <Login/>
          </Route>
          <Route exact path="/articles">
            <Articles/>
          </Route>
          <Route path = '/articles/:slug'>
            <ArticlesDetails/>
          </Route>
          <Route path = "/create-article">
            <CreateArticle/>
          </Route>
        </Switch>
      </BrowserRouter>
    </div>
  )
}

export default App

