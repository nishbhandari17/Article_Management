import axios from 'axios'

const url = `https://conduit.productionready.io/api`

const authLogin = async ({ email, password }) => {
    try {
        const auth = await axios.post(url + "/users/login", {
                user: { 
                    "email": email, 
                    "password": password 
                }
            }
        );
        return auth.data.user;
    } catch (e) {
        if (e.response) {
            return e.response.data;
        }
        return "Encountered an exception! Please try again after sometime!";
    }
}

const getArticles = async () => {
    try{
        const articles = await axios.get(`${url}/articles`)
        console.log(articles)
        return articles.data.articles
    } catch (e) {
        if (e.response) {
            return e.response.data;
        }
        return "Encountered an exception! Please try again after sometime!";
    }
}

const getArticle = async (slug) => {
    try{
        const article = await axios.get(`${url}/articles/${slug}`)
        console.log(article)
        return article.data.article
    } catch (e) {
        if (e.response) {
            return e.response.data;
        }
        return "Encountered an exception! Please try again after sometime!";
    }
}

const postArticle = async ({title, description, body, tagList}) => {
    try {
        const accessToken = localStorage.getItem('token')
        const headers = { 'Authorization': `Token ${accessToken}` }
        const savedArticle = await axios.post(`${url}/articles`, {
                article: { 
                    title, 
                    body, 
                    description, 
                    tagList
                }
            }
            , { headers }
        );
        return savedArticle.data;
    } catch (err) {
        console.log(err)
        throw new Error('Article couldn\'t be saved')
    }
}

const getUser = async () => {
    try {
        const accessToken = localStorage.getItem('token')
        const headers = { 'Authorization': `Token ${accessToken}` }
        const user = await axios.get(`${url}/user`, {headers})

        return user.data.user
    } catch (e) {
        if (e.response) {
            return e.response.data;
        }
        return "Encountered an exception! Please try again after sometime!";
    }
}

const delArticle = async (slug) => {
    try {
        const accessToken = localStorage.getItem('token')
        const headers = { 'Authorization': `Token ${accessToken}` }
        const response = await axios.delete(`${url}/articles/${slug}`, {headers})
        return response
    } catch (e) {
        if (e.response) {
            return e.response.data;
        }
        return "Encountered an exception! Please try again after sometime!";
    }
}

export {
    authLogin,
    getArticles,
    getArticle,
    postArticle,
    getUser,
    delArticle
}